﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Megye megye;

        public MainWindow()
        {
            megye = new Megye();
            InitializeComponent();
            listboxfeltoltes(megye.Telepuleslista); 
            // adatoklistbox.ItemsSource = megye.Telepuleslista;

            List<string> halmaz = megye.kistersegekneve();
            for (int i = 0; i <halmaz.Count ; i++)
            {
                comboboxelemek.Items.Add(halmaz[i]);
            }




        }

        private void listboxfeltoltes(List<Telepules> lista)
        {
            for (int i = 0;i < lista.Count ; i++)
            {
                adatoklistbox.Items.Add(lista[i].ToString());
            }
        }

        private void comboboxelemek_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            
            
            if(comboboxelemek.SelectedIndex > -1)
            {
                List<Telepules> kivalogatott = megye.kivalogatkisterseg(comboboxelemek.SelectedValue.ToString());
                listboxfeltoltes(kivalogatott);
                csakaszurtelemekre.IsEnabled = true;

                

            }
            
           
        }
        private void alaphelyzet(List<Telepules> lista)
        {
            adatoklistbox.Items.Clear();
            listboxfeltoltes(lista);
            torlesgomb.IsEnabled = true;
            csakaszurtelemekre.IsEnabled = false;
            csakaszurtelemekre.IsChecked = false;
            atlagnepessegbtn.IsChecked = true;
            osszesteruletbtn.IsChecked = false;
            eredmenytextbox.Text = string.Empty;
            

        }

        private void torlesgomb_Click(object sender, RoutedEventArgs e)
        {
            alaphelyzet(megye.Telepuleslista);
            comboboxelemek.SelectedIndex = -1;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            
            
            if (atlagnepessegbtn.IsChecked == true)
            {
                if (csakaszurtelemekre.IsChecked == false)
                {
                    eredmenytextbox.Text = $"Átlagnépesség: {megye.Nepessegatlag()}";
                }
                else
                {
                    eredmenytextbox.Text = $"Átlagnépesség: {megye.nepessegatlag(comboboxelemek.SelectedValue.ToString())} fő";
                }

            }
            else
            {
                if(osszesteruletbtn.IsChecked == true)
                {
                    if (csakaszurtelemekre.IsChecked == false)
                    {
                        eredmenytextbox.Text = $"Összeterület: {megye.Teruletosszegzes()} hektár"; 
                    }
                    else
                    {
                        eredmenytextbox.Text = $"Összeterület: {megye.Teruletosszegzes()} hektár";
                    }
                }
                else
                {
                    MessageBox.Show("Nem választott feladatot");
                }
            }
        }

        
    }
}

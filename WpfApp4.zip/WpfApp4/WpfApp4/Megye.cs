﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Navigation;

namespace WpfApp4
{
    internal class Megye
    {
        private List<Telepules> telepuleslista;

        internal List<Telepules> Telepuleslista { get => telepuleslista; set => telepuleslista = value; }

        public Megye()
        {
            Telepuleslista = new List<Telepules>();
            beolvasas();

        }

        public List<Telepules> beolvasas()
        {
            FileStream fs = new FileStream("statisztika.csv", FileMode.Open);
            StreamReader sr = new StreamReader(fs, Encoding.UTF8);
            sr.ReadLine();
            while (!sr.EndOfStream)
            {
                string[] sor = sr.ReadLine().Split(';');
                Telepuleslista.Add(new Telepules(Convert.ToInt32(sor[0]),
                    sor[1],
                    sor[2],
                    sor[3],
                    Convert.ToInt32(sor[4]),
                    Convert.ToInt32(sor[5]),
                    Convert.ToInt32(sor[6])));


            }
            fs.Close();
            sr.Close();
            return Telepuleslista;
















        }

        public double Nepessegatlag()
        {
            double szum = 0;
            for (int i = 0; i < Telepuleslista.Count; i++)
            {
                szum += Telepuleslista[i].Nepesseg;
            }
            return szum / Telepuleslista.Count;

        }

        public double nepessegatlag(string kistersegnev)
        {
            double szum = 0;
            int db = 0;
            for(int i = 0; i < Telepuleslista.Count; i++)
            {
                if (Telepuleslista[i].Kistersegnev == kistersegnev)
                {
                    szum += Telepuleslista[i].Nepesseg;
                    db++;

                }
            }
            return szum / db;
        }

        public int Teruletosszegzes()
        {
            int szum = 0;
            for (int i = 0; i < Telepuleslista.Count; i++)
            {
                szum += Telepuleslista[i].Terulet;
            }








            return szum;
        }
        public int Teruletosszegzes(string kistersegnev)
        {
            int szum = 0;
            for (int i = 0; i < Telepuleslista.Count; i++)
            {
                if(kistersegnev == Telepuleslista[i].Kistersegnev)
                {
                    szum += Telepuleslista[i].Terulet;
                }
            }
            return szum;

        }

        public List<string> kistersegekneve()
        {
            List<string> eredmeny = new List<string>();
            for (int i = 0; i < Telepuleslista.Count; i++)
            {
                if (eredmeny.Contains(Telepuleslista[i].Kistersegnev))
                {
                    eredmeny.Add(Telepuleslista[i].Kistersegnev);
                }
            }
            return eredmeny;
            
            
            
            
            
            
            
            
           
        }
        public List<string> kistersegekneveeldontessel()
        {
            List<string> eredmeny = new List<string>();

            for (int i = 0; i < Telepuleslista.Count; i++)
            {
                if (!szerepele(Telepuleslista[i].Kistersegnev, eredmeny))
                {
                    eredmeny.Add(Telepuleslista[i].Kistersegnev);
                }
            }
            return eredmeny;
        }
        private bool szerepele(string mi, List<string> miben)
        {
            bool valasz;
            int i = 0;
            while (i < miben.Count && miben[i] != mi)
            {
                i++;
            }
            if (i < miben.Count)
            {
                valasz = true;
            }
            else
            {
                valasz = false;
            }
            return valasz;
            
            
        }
        public HashSet<string> kistersegekhalmazzal()
        {
            HashSet<string> eredmeny = new HashSet<string> ();

            for (int i = 0; i < Telepuleslista .Count; i++)
            {
                eredmeny.Add(Telepuleslista[i].Kistersegnev);
            }
            return eredmeny;
        }

        // bejárás -- > nincs index, ezért ElementAt(index) metódussal hivatkozunk az elemekre


        public List<Telepules> kivalogatkisterseg(string kistersegneve)
        {
            List<Telepules> kivalogatott = new List<Telepules>();
            for (int i = 0; i < telepuleslista.Count; i++)
            {
                if (telepuleslista[i].Kistersegnev == kistersegneve)
                {
                    kivalogatott.Add(telepuleslista[i]);
                }
            }
            
            return kivalogatott;
        }
    }
}

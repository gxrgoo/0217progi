﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp4
{
    internal class Telepules
    {
        private int azonosito;
        private string nev;
        private string rang;
        private string kistersegnev;
        private int terulet;
        private int nepesseg;
        private int lakasokszama;

        public Telepules(int azonosito, string nev, string rang, string kistersegnev, int terulet, int nepesseg, int lakasokszama)
        {
            this.azonosito = azonosito;
            this.nev = nev;
            this.rang = rang;
            Kistersegnev = kistersegnev;
            Terulet = terulet;
            Nepesseg = nepesseg;
            this.lakasokszama = lakasokszama;
        }

     
        public int Terulet { get => terulet; set => terulet = value; }
        public int Nepesseg { get => nepesseg; set => nepesseg = value; }
        public string Kistersegnev { get => kistersegnev; set => kistersegnev = value; }

        public override string ToString()
        {
            return $"{nev} {rang} {Kistersegnev} {terulet} {nepesseg} {lakasokszama}";
        }
    }
}
